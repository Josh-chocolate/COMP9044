#!/bin/dash

for directory in "$@"
do
	if ! [ -d "${directory%/*}" ]
	then
		echo "Directory ${directory} doesn't exist."
		exit 1
	else
		for file in "${directory%/*}"*
		do
			suffix=`echo "$file" | sed 's/.*\(....\)$/\1/'`
			if [ "$suffix" = ".mp3" ]
			then
				echo "$file"
				title=`echo "$file" | cut -d'/' -f3 | cut -d'-' -f2 | sed 's/ //g'`
				artist=`echo "$file" | cut -d'.' -f1 | cut -d'-' -f3 | sed 's/^ //g'`
				track=`echo "$file" | cut -d'/' -f3 | cut -d'-' -f1 | sed 's/ $//g'`
				album=`echo "$file" | cut -d'/' -f2`
				year=`echo "$file" | cut -d'/' -f2 | cut -d',' -f2 | sed 's/^ //g'`
				
				id3 "$file" -t "$title" >/dev/null
				id3 "$file" -a "$artist" >/dev/null
				id3 "$file" -T "$track" >/dev/null
				id3 "$file" -A "$album" >/dev/null
				id3 "$file" -y "$year" >/dev/null
				id3 -l "$file"
			fi
		done
	fi
done
